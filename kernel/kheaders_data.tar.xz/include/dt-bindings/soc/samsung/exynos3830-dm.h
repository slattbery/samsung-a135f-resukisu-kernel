

#ifndef _DT_BINDINGS_EXYNOS_3830_H
#define _DT_BINDINGS_EXYNOS_3830_H


#define DM_CPU_CL0	0
#define DM_CPU_CL1	1
#define DM_MIF		2
#define DM_INT		3
#define DM_CAM		5
#define DM_DISP		6
#define DM_AUD		7
#define DM_GPU		8


#define CONSTRAINT_MIN	0
#define CONSTRAINT_MAX	1

#endif	
