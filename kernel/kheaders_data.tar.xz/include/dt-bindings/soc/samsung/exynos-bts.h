

#ifndef __DT_BINDINGS_EXYNOS_BTS_H
#define __DT_BINDINGS_EXYNOS_BTS_H


#define IP_BTS			(0x1)
#define TREX_BTS		(0x2)
#define SCI_BTS			(0x3)
#define SMC_BTS			(0x4)
#define BUSC_BTS		(0x5)
#define DREX_BTS		(0x6)
#define INTERNAL_BTS		(0x7)

#endif 
