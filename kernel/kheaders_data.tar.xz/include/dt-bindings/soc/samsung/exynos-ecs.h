

#ifndef __EXYNOS_SPARING_GOVERNOR
#define __EXYNOS_SPARING_GOVERNOR


#define NORMAL			(0x0)
#define BOOSTING		(0x1 << 0)
#define SAVING			(0x1 << 1)


#define	NOTHING			(0x0)
#define	TRIGGER			(0x1 << 0)
#define	BOOSTER			(0x1 << 1)
#define SAVER			(0x1 << 2)
#define	TRIGGER_AND_BOOSTER	(TRIGGER | BOOSTER)
#define TRIGGER_AND_SAVER	(TRIGGER | SAVER)

#endif 
