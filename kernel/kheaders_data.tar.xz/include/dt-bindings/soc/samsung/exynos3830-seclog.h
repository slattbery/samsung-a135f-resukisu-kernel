

#ifndef EXYNOS3830_SECLOG_H
#define EXYNOS3830_SECLOG_H


#define SECLOG_NUM_OF_CPU                       (8)


#define SECLOG_LOG_BUF_BASE                     (0xC3000000)
#define SECLOG_LOG_BUF_SIZE                     (0x10000)
#define SECLOG_LOG_BUF_TOTAL_SIZE               (SECLOG_LOG_BUF_SIZE * SECLOG_NUM_OF_CPU)

#endif  
